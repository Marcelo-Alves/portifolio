@extends('admin.template.template')
@section('admintitulo')
Painel Quem Sou
@endsection
@section('adminconteudo')
  <h1>Quem sou</h1>
  <p>
      Com mais de 20 anos de experiência na area de TI, sou formado em Tecnologia da Informação com MBA em Gestão Estratégica de TI <br>
      pela Fundação Getúlio Vargas. A minha carreira foi desenvolvida em empresas de grande porte como Petrobras, <br>
      Accenture e T-Systems e atualmente Locaweb.
      Possuo experiência na reestruturação de equipes de TI, capacidade de liderança e motivação de equipes, <br>
      habilidade para identificar problemas complexos e implantar soluções que agregam valor aos negócios. 
  </p>
  
@endsection