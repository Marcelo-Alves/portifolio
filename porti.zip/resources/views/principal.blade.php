@extends('template.template')

@section('titulo')
SEJA BEM VINDO
@stop

@section('conteudo')
<h1>Principal</h1>
@stop