

<?php $__env->startSection('titulo'); ?>
CONTATO
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<form action="" method="post">
    <h1>Contato</h1>
    <div>
        <label for="nome">Nome</label>
        <input type="text" name="nome" id="nome" placeholder="Nome">
    </div>
    <div>
        <label for="email">Email</label>
        <input type="email" name="email" id="email" placeholder="E-mail">
    </div>
    <div>
        <label for="observacao">Observação</label>
        <textarea name="observacao" id="observacao" cols="30" rows="10" placeholder="Observação"></textarea>
    </div>
    <div>
        <input type="submit" value="Enviar">
        </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marcelo\Documents\teste\portifolio\resources\views/contato.blade.php ENDPATH**/ ?>