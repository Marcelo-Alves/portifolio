
<h1>TELA DE LOGIN</h1>

<div class="form-group">
    <label for="txtnome">Nome</label>
    <input type="text" class="form-control" id="txtlogin" name="txtlogin" placeholder="Digite seu Login">
</div>

<div class="form-group">
    <label for="txtsenha">Senha</label>
    <input type="password" class="form-control" id="txtsenha" name="txtsenha" placeholder="Digite sua senha">
</div>
<input type="submit" class="form-control" value="Logar">
<input type="reset" class="form-control" value="Cancelar">

<?php /**PATH C:\Users\Marcelo\Documents\teste\portifolio\resources\views/admin/login.blade.php ENDPATH**/ ?>