
<?php $__env->startSection('admintitulo'); ?>
Painel Quem Sou
<?php $__env->stopSection(); ?>
<?php $__env->startSection('adminconteudo'); ?>
  <h1>Quem sou</h1>
  <p>
      Com mais de 20 anos de experiência na area de TI, sou formado em Tecnologia da Informação com MBA em Gestão Estratégica de TI <br>
      pela Fundação Getúlio Vargas. A minha carreira foi desenvolvida em empresas de grande porte como Petrobras, <br>
      Accenture e T-Systems e atualmente Locaweb.
      Possuo experiência na reestruturação de equipes de TI, capacidade de liderança e motivação de equipes, <br>
      habilidade para identificar problemas complexos e implantar soluções que agregam valor aos negócios. 
  </p>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/marcelo/Dados/teste/portifolio/resources/views/admin/adminquem.blade.php ENDPATH**/ ?>