

<?php $__env->startSection('titulo'); ?>
QUEM SOU E EXPERIÊNCIA
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<div class="container">
<?php $__currentLoopData = $QUEM; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <h1><?php echo e($quem->TITULO); ?></h1>
    <p>
        <?php echo e($quem->TEXTO); ?>

    </p>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.template.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\teste\portifolio\resources\views/site/quem.blade.php ENDPATH**/ ?>