

<?php $__env->startSection('titulo'); ?>
QUEM SOU
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<h1>Quem sou</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marcelo\Documents\teste\portifolio\resources\views/quem.blade.php ENDPATH**/ ?>