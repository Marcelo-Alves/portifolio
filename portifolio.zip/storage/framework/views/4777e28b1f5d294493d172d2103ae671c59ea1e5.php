
<?php $__env->startSection('admintitulo'); ?>
Painel Contato
<?php $__env->stopSection(); ?>
<?php $__env->startSection('adminconteudo'); ?>
<h1>Contato Admin</h1>
<div class="table-responsive">
    <table class="table table-striped">
      <thead>
        <tr>
          <th>Nome</th>
          <th>Email</th>
          <th>Mensagem</th>
          <th>Data</th>
        </tr>
      </thead>
            <tbody>
            <?php $__currentLoopData = $CONTATOS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($contato->nome); ?></td>
              <td><?php echo e($contato->email); ?></td>
              <td><?php echo e($contato->mensagem); ?></td>
              <td><?php echo e(date('d/m/Y H:i:s', strtotime($contato->data))); ?></td>
            </tr>                   
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/marcelo/Documentos/teste/portifolio/resources/views/admin/admincontato.blade.php ENDPATH**/ ?>