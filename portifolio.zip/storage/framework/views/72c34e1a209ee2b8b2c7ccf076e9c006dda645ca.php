
<h1>Contato do site</h1>
<p>
    Logo entrarem em contato
</p>

<?php /**PATH /home/marcelo/Documentos/teste/portifolio/resources/views/site/mail.blade.php ENDPATH**/ ?>