@extends('template.template')

@section('titulo')
NOTÍCIAS
@stop

@section('conteudo')
<h1>Notícias</h1>
@stop